﻿using System;

namespace InsumosMedicosJDJ.Models
{
    public class ProductoTela
    {
        public Guid Id { get; set; }

        public string NombreProducto { get; set; }

        public string Modelo { get; set; }
    }
}