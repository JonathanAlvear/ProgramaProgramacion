﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace InsumosMedicosJDJ.Migrations
{
    public partial class ProduccionMedicos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Producciones",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Fecha_produccion = table.Column<int>(nullable: false),
                    Cantidad_prendas = table.Column<int>(nullable: false),
                    Costo_unidad = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Producciones", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Producciones");
        }
    }
}
